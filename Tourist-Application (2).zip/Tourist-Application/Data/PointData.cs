
using System.Collections.Generic;
using Points.Models;

namespace Points.Data
{
    static class PointData
    {
        public static List<Point> points = new List<Point>();
        
    }    
}